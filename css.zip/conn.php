<?php 
    mysql_connect("localhost","dapps","l1m4d1g1t");
    mysql_select_db("dapps_joker_masimanetwork_prambors");
?>
<link rel="icon" href="images/favicon.png" type="image/x-icon" />
    <title>Pramborss Radio</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Prambors merupakan radio hits anak muda nomor satu di jakarta">
    <meta name="keywords" content="Radio Prambors, Radio Anak Muda, Radio Hits Jakarta">
    <meta name="author" content="LimaDigit">
    <meta name="theme-color" content="#ffc925">

        <style type="text/css">
            ::-webkit-scrollbar-button{ display: block; height: 13px; border-radius: 0px; background-color: #AAA; } ::-webkit-scrollbar-button:hover{ background-color: #AAA; } ::-webkit-scrollbar-thumb{ background-color: #ffff00; border-radius: 10px; } ::-webkit-scrollbar-thumb:hover{ background-color: #ffff00; border-radius: 10px; } ::-webkit-scrollbar-track{ background-color: #7e7e7e; } ::-webkit-scrollbar-track:hover{ background-color: #ffc925; } ::-webkit-scrollbar{ width: 10px; }
        </style>