<div class="top2_wrapper" id="top2">
    <div class="container">

        <div class="top2 clearfix">

            <header>
                <div class="logo_wrapper">
                    <a href="index.php" class="logo scroll-to">
                        <img src="images/prambors_asset/stripe.png" style="height: 60px;" alt="" class="img-responsive" style="">
                    </a>
                </div>
            </header>

            <div class="menu_wrapper">
                <div class="add1 clearfix" style="display: none;">
                    <div class="icon-search"><a href="#"></a></div>
                    <div class="dropdown dropdown1">
                        <button class="dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="true">EN
                        </button>

                    </div>
                </div>
                <div class="navbar navbar_ navbar-default">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                            data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="navbar-collapse navbar-collapse_ collapse" >
                        <ul class="nav navbar-nav sf-menu clearfix">
                            
                            <li><a href="#home"><b class="menubar_item"></b>AAAA</a></li>
                            <li><a href="#music"><b class="menubar_item">MUSIC</b></a></li>
                            <li><a href="#shows"><b class="menubar_item">OUR SHOWS</b></a></li>
                            <li><a href="#djs"><b class="menubar_item">Wadyabala</b></a></li>
                            <li><a href="#news"><b class="menubar_item">NEWS</b></a></li>
                            <li><a href="#event_promo"><b class="menubar_item">EVENTS & PROMO</b></a></li>
                             
                        </ul>
                    </div>
                </div>
            </div>


        </div>

    </div>
</div>
<style type="text/css">
    .menubar_item:hover{
        color: #ffc925;
        transition: 0.5s;
    }
    
</style>