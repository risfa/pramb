
<div class="container">
    <br><br><br>
    <div class="title2 animated" data-animation="fadeInUp" data-animation-delay="100" style="color: black">PRAMBORS NEWS
    </div>

    <div class="title3 animated" data-animation="fadeInUp" data-animation-delay="200">Ayo bikin diri kamu lebih up to date!</div>
</div>

<br><br>

<div class="container">
    <div class="row">
        <div class="col-md-6" style="padding: 15px; border-radius: 5px; background-color: black;" >
            <div>
            <?php 
                $data_news_1 = mysql_fetch_array(mysql_query("SELECT * FROM news ORDER BY ID DESC LIMIT 1 OFFSET 0 ")); 
            ?>
            <div class="post post-short" >
                <div class="post-header">
                    <div class="post-image">
                        
                        <style>
                            .center-cropped {
                              width: 555px;
                              height: 455px;
                              background-position: center center;
                              background-repeat: no-repeat;
                              background-size: auto 100%;
                            }
                        </style>
                        <div class="center-cropped" style="background-image: url('prambors_images_assets/news/<?php echo $data_news_1[0]  ?>.jpg');"></div>
                        
                    </div>
                </div>
                <div class="post-story">
                    <div class="post-story-body" style="color: white;  margin-bottom: -50px !important;">
            
                        <p class="txt1" style="color: #ffc925; margin-top: 10px;">
                            <a style='padding:2px; text-decoration:none;' href='pages/news_details.php?details=<?php echo $data_news_1[0] ?>'>
                            <font style="font-size: 40px; line-height: 80%; color: #ffc925; font-weight: bold;"><?php echo htmlspecialchars_decode($data_news_1[4]) ?></font></a><br style="color: white;">
                            <?php 
                            $content = preg_replace("/<img[^>]+\>/i", "", $data_news_1[3]); 
                            echo htmlspecialchars_decode(substr($content,0,150))." ..." ?><br>

                          <!--   $content = "this is something with an <img src=\"test.png\"/> in it.";
                            
                            echo $content; -->


                            <a class='hover_oranye_tipis' style='background:none; color:#ffc925; padding:2px; text-decoration:none; font-weight: bold;' href='pages/news_details.php?details=<?php echo $data_news_1[0] ?>'><b>Read More</b></a>
                            <br>
                            <!-- By <?php echo $data_news_1[1]; ?> |  --><?php echo $data_news_1[2] ?>
                        </p>
                    </div>
                </div>
            </div>
            </div>
        </div>
        <div class="col-md-6" style="border:none solid 2px;padding: 0px 10px 10px 10px; border-radius: 5px;">
            
            <?php 
                $sql = mysql_query("SELECT * FROM news ORDER BY ID DESC LIMIT 5 OFFSET 1"); 
                    while($news_data = mysql_fetch_array($sql)){
            ?>

            <div class="latest1"  style="padding: 5px; margin-top: 5px; border-radius: 5px; color: black;">
                <a href="pages/news_details.php?details=<?php echo $news_data[0] ?>" class="clearfix">
                    <style>
                            .center-cropped2 {
                              width: 150px;
                              height: 100px;
                              background-position: center center;
                              background-repeat: no-repeat;
                              background-size: auto 100%;
                                  background-color: black;
                            }
                        </style>
                        
                        
                    <figure><div class="center-cropped2" style="background-image: url('prambors_images_assets/news/<?php echo $news_data[0]  ?>.jpg');"></div></figure>
                    <div class="caption" style="color:black">
                        <div class="txt1"><font style="font-size: 20px; line-height: 90%; color: black;"><?php echo htmlspecialchars_decode($news_data[4]) ?></font></div>
                        <?php 
                            $content2 = preg_replace("/<img[^>]+\>/i", "", $news_data[3]); 
                            echo htmlspecialchars_decode(substr($content2,0,100))." ..." ?>          
                        <font style="color: black;"><!-- By <?php echo $news_data[1]; ?> | --> <?php echo $news_data[2] ?></font>
                    </div>
                </a>
            </div>

            <?php } ?>
            
        </div>   

        <div class="row">
            <div class="col-md-12">
                <div style="float: right; margin-right: 15px;">
                    <a href="pages/news.php" class="btn-default btn3 animated fadeInDown blink" style="color: black; background: url(images/arr2.png) right center no-repeat">READ MORE NEWS</a>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br>