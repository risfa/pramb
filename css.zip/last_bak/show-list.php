<div class="container negative-nienety" style="">
            <div class="title2 animated" data-animation="fadeInUp" data-animation-delay="100" style="color: black">PRAMBORS SHOW LISTS
            </div>

            <div class="title3 animated" data-animation="fadeInUp" data-animation-delay="200">Lorem ipsum dolor sit amet
                concateur non tropp sit namo, allegro sustenuto al prada bravo pensare, chicco milo naturo
            </div>
        </div>
        <br><br><br>
        <br><br><br>

        <div class="container">

            <div class="slick-slider slider center">
                <div>
                    <div class="slick-slider-inner">
                        <figure><img src="images/banner1.jpg" alt="" class="img-responsive"></figure>
                        <div class="caption">
                            <div class="txt1"><span>Music - John Coltrain</span></div>
                            <div class="txt2"><span>The Dream Of My Life</span></div>
                            <div class="txt3"><a href="#" class="btn-default btn1">MORE DETAILS</a></div>
                        </div>
                        <div class="slick-slider-overlay"></div>
                    </div>
                </div>
                <div>
                    <div class="slick-slider-inner">
                        <figure><img src="images/banner2.jpg" alt="" class="img-responsive"></figure>
                        <div class="caption">
                            <div class="txt1"><span>Music - Janette Colins</span></div>
                            <div class="txt2"><span>The Music Is My Life</span></div>
                            <div class="txt3"><a href="#" class="btn-default btn1">MORE DETAILS</a></div>
                        </div>
                        <div class="slick-slider-overlay"></div>
                    </div>
                </div>
                <div>
                    <div class="slick-slider-inner">
                        <figure><img src="images/banner3.jpg" alt="" class="img-responsive"></figure>
                        <div class="caption">
                            <div class="txt1"><span>Music - Marianna Johns</span></div>
                            <div class="txt2"><span>Bing & Bong</span></div>
                            <div class="txt3"><a href="#" class="btn-default btn1">MORE DETAILS</a></div>
                        </div>
                        <div class="slick-slider-overlay"></div>
                    </div>
                </div>
                <div>
                    <div class="slick-slider-inner">
                        <figure><img src="images/banner4.jpg" alt="" class="img-responsive"></figure>
                        <div class="caption">
                            <div class="txt1"><span>Music - Lino Ventura</span></div>
                            <div class="txt2"><span>La Prima Di Casta</span></div>
                            <div class="txt3"><a href="#" class="btn-default btn1">MORE DETAILS</a></div>
                        </div>
                        <div class="slick-slider-overlay"></div>
                    </div>
                </div>
                <div>
                    <div class="slick-slider-inner">
                        <figure><img src="images/banner5.jpg" alt="" class="img-responsive"></figure>
                        <div class="caption">
                            <div class="txt1"><span>Music - Amanda Geferson</span></div>
                            <div class="txt2"><span>Non Troppo Di Piano</span></div>
                            <div class="txt3"><a href="#" class="btn-default btn1">MORE DETAILS</a></div>
                        </div>
                        <div class="slick-slider-overlay"></div>
                    </div>
                </div>

                <div>
                    <div class="slick-slider-inner">
                        <figure><img src="images/banner1.jpg" alt="" class="img-responsive"></figure>
                        <div class="caption">
                            <div class="txt1"><span>Music - Arturo Chiritto</span></div>
                            <div class="txt2"><span>You Are My Life</span></div>
                            <div class="txt3"><a href="#" class="btn-default btn1">MORE DETAILS</a></div>
                        </div>
                        <div class="slick-slider-overlay"></div>
                    </div>
                </div>
                <div>
                    <div class="slick-slider-inner">
                        <figure><img src="images/banner2.jpg" alt="" class="img-responsive"></figure>
                        <div class="caption">
                            <div class="txt1"><span>Music - Cata Jikia</span></div>
                            <div class="txt2"><span>My Love</span></div>
                            <div class="txt3"><a href="#" class="btn-default btn1">MORE DETAILS</a></div>
                        </div>
                        <div class="slick-slider-overlay"></div>
                    </div>
                </div>
                <div>
                    <div class="slick-slider-inner">
                        <figure><img src="images/banner3.jpg" alt="" class="img-responsive"></figure>
                        <div class="caption">
                            <div class="txt1"><span>Music - Meco Vachini</span></div>
                            <div class="txt2"><span>Simavera Di Nappoli</span></div>
                            <div class="txt3"><a href="#" class="btn-default btn1">MORE DETAILS</a></div>
                        </div>
                        <div class="slick-slider-overlay"></div>
                    </div>
                </div>
                <div>
                    <div class="slick-slider-inner">
                        <figure><img src="images/banner4.jpg" alt="" class="img-responsive"></figure>
                        <div class="caption">
                            <div class="txt1"><span>Music - Maya Chekura</span></div>
                            <div class="txt2"><span>Shalva You Are My Life</span></div>
                            <div class="txt3"><a href="#" class="btn-default btn1">MORE DETAILS</a></div>
                        </div>
                        <div class="slick-slider-overlay"></div>
                    </div>
                </div>
                <div>
                    <div class="slick-slider-inner">
                        <figure><img src="images/banner5.jpg" alt="" class="img-responsive"></figure>
                        <div class="caption">
                            <div class="txt1"><span>Music - John Smith</span></div>
                            <div class="txt2"><span>Primo Di Tammoro</span></div>
                            <div class="txt3"><a href="#" class="btn-default btn1">MORE DETAILS</a></div>
                        </div>
                        <div class="slick-slider-overlay"></div>
                    </div>
                </div>


            </div>
        </div>