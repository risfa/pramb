<div class="container">
    <br><br><br>
    <div class="title2 animated" data-animation="fadeInUp" data-animation-delay="100" style="color: black">PRAMBORS NEWS
    </div>

    <div class="title3 animated" data-animation="fadeInUp" data-animation-delay="200">Lorem ipsum dolor sit amet
        concateur non tropp sit namo, allegro sustenuto al prada bravo pensare, chicco milo naturo
    </div>
</div>

<br><br>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="post post-short">
                <div class="post-header">
                    <div class="post-image">
                        <img src="images/post02.jpg" alt="" class="img-responsive">
                    </div>
                </div>
                <div class="post-story">
                    <div class="post-story-body clearfix">
                        <p class="txt1" >
                            <font style="font-size: 40px">Lipsum Dolor sit Amet</font><br>
                            vel leo. In vulputate eros pellentesque neque cursus, in elementum augue semper.
                            Duis eleifend aliquam mi, nec ornare ligula tincidunt eu.
                        </p>

                    </div>
                    <div class="post-story-link">
                        <a href="post.html" class="btn-default btn6">PREVIEW POST</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            
            <div class="latest1">
                <a href="#" class="clearfix">
                    <figure><img src="images/latest01.jpg" alt=""  style="height: 100px;"></figure>
                    <div class="caption">
                        <div class="txt1"><font style="font-size: 20px">Lorem ipsum dolor sit amet</font><br> concateur un otto bravo netto,concateur un otto bravo netto,concateur un otto bravo netto, sustenuto
                            non troppo.
                        </div>
                        <div class="txt2">January 17 - 2016</div>
                    </div>
                </a>
            </div>
            
            <div class="latest1">
                <a href="#" class="clearfix">
                    <figure><img src="images/latest01.jpg" alt="" style="height: 100px;"></figure>
                    <div class="caption">
                        <div class="txt1"><font style="font-size: 20px">Lorem ipsum dolor sit amet</font><br> concateur un otto bravo netto,concateur un otto bravo netto,concateur un otto bravo netto, sustenuto
                            non troppo.
                        </div>
                        <div class="txt2">January 17 - 2016</div>
                    </div>
                </a>
            </div>

            <div class="latest1">
                <a href="#" class="clearfix">
                    <figure><img src="images/latest01.jpg" alt="" style="height: 100px;"></figure>
                    <div class="caption">
                        <div class="txt1"><font style="font-size: 20px">Lorem ipsum dolor sit amet</font><br> concateur un otto bravo netto,concateur un otto bravo netto,concateur un otto bravo netto, sustenuto
                            non troppo.
                        </div>
                        <div class="txt2">January 17 - 2016</div>
                    </div>
                </a>
            </div>

            <div class="latest1">
                <a href="#" class="clearfix">
                    <figure><img src="images/latest01.jpg" alt="" style="height: 100px;"></figure>
                    <div class="caption">
                        <div class="txt1"><font style="font-size: 20px">Lorem ipsum dolor sit amet</font><br> concateur un otto bravo netto,concateur un otto bravo netto,concateur un otto bravo netto, sustenuto
                            non troppo.
                        </div>
                        <div class="txt2">January 17 - 2016</div>
                    </div>
                </a>
            </div>                    

        </div>
    </div>
</div>
<br><br>