    <div id="home">
        <center>
            <div class="logo3_wrapper hidden-sm hidden-xs">
                <img src="images/prambors_asset/big logo.png" class="img-responsive ">
            </div>
        </center>
       
        <div id="slider_wrapper">
            <div id="slider_inner" class="clearfix">

                <div id="slider" class="clearfix" style="margin-left: -50px;">
                    <div id="camera_wrap">
                        <div data-src="images/slide01.jpg"></div>
                        <div data-src="images/slide02.jpg"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="song1_wrapper">
        <div class="container">
            <div class="song1_inner clearfix">
                <div class="song1 clearfix">

                    <div class="left clearfix">
                        <figure><img src="images/song1.jpg" alt="" height="90px" width="110px"></figure>
                        <div class="caption">
                            <div class="txt1">Prambors Streaming : Semangat Pagi</div>
                            <div class="txt2">
                            	<div class="audio1" style="margin-top: -2px;" >
	                           		<button type="button" class="btn" style="background: none; border: #ffc925 solid 1px; "><font style="color:#ffc925" class="fa fa-pause"></font></button>
	                           		<button type="button" class="btn" style="background: none; border: #ffc925 solid 1px; "><font style="color:#ffc925" class="fa fa-play"></font></button>
	                           		<button type="button" class="btn" style="background: none; border: #ffc925 solid 1px; "><font style="color:#ffc925" class="fa fa-volume-up"></font></button>
	                            </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="right">
                        <img src="images/jukebox.jpg" style="height:90px">
                        <font style="font-size: 15px; margin-top: 5px;">#DengerBareng</font>
                    </div>

                </div>
            </div>
        </div>
    </div>
