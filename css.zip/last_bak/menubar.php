<div id="top1">
        <div class="top2_wrapper" id="top2">
            <div class="container">

                <div class="top2 clearfix">

                    <header>
                        <div class="logo_wrapper">
                            <a href="#home" class="logo scroll-to">
                                <img src="images/prambors_asset/stripe.png" alt="" class="img-responsive" style="">
                            </a>
                        </div>
                    </header>

                    <div class="menu_wrapper">

                        <div class="navbar navbar_ navbar-default">

                            <div class="navbar-collapse navbar-collapse_ collapse" >
                                <ul class="nav navbar-nav sf-menu clearfix">
                                    <li class="sub-menu sub-menu-1"><a href="#home"><b>Home</b></a></li>
                                    <li><a href="#music"><b>MUSIC</b></a></li>
                                    <li><a href="#shows"><b>OUR SHOWS</b></a></li>
                                    <li><a href="#djs"><b>Wadyabala</b></a></li>
                                    <li><a href="#news"><b>NEWS</b></a></li>
                                    <li><a href="#event_promo"><b>EVENT & PROMO</b></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>


                </div>

            </div>
        </div>

    </div>