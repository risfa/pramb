<!DOCTYPE html>
<script>
function myFunction1() {
    var x = document.getElementById("baba");
    if (x.style.display === "none") {
        x.style.display = "block";
    }
}
</script>
<html lang="en">
<?php 
    include("../conn.php");
?>
<head>
    <!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css" integrity="sha384-3AB7yXWz4OeoZcPbieVW64vVXEwADiYyAEhwilzWsLw+9FgqpyjjStpPnpBO8o8S" crossorigin="anonymous"> -->
    <link rel="icon" href="../images/favicon.png" type="image/x-icon" />
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/font-awesome.css" rel="stylesheet">
    <link href="../css/camera.css" rel="stylesheet">
    <link href="../css/mediaelementplayer.css" rel="stylesheet">
    <link href="../css/slick.css" rel="stylesheet">
    <link href="../css/my_css.css" rel="stylesheet">
    <link href="../css/slick-theme.css" rel="stylesheet">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">

</head>
<body class="onepage front" data-spy="scroll" data-target="#top1" data-offset="92">

<div id="load"></div>

<div id="main">

    <div id="home">
        <?php include("../index_parts/page_slider.php"); ?>
    </div>

    <div id="top1">
        <?php include("../index_parts/page_menubar.php"); ?>
    </div>

        <?php include('../index_parts/ads_slot.php') ?>
        
        <div class="container" class="backdrop">
            <br><br><br>
            <div class="row">
                <div class="col-md-12">
                    <h1 style="color: #ffc925; font-weight: bold;">Prambors News Feed</h1>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-md-8">
                    <?php 
                        include('pagination_ajax/index.php');
                     ?>
                </div>
<!--                 <div class="col-md-8" style="display: none;">
                    <?php 
                        $sql_news = mysql_query("SELECT * FROM news ORDER BY ID DESC LIMIT 5 "); 
                        while($data_news_1 = mysql_fetch_array($sql_news)){
                    ?>
                    <div class="post post-short animated" data-animation="fadeInRight" data-animation-delay="500" style="margin-top:-20px; color: white;">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="post-header">
                                    <div class="post-image">
                                        <img src="../prambors_images_assets/news/<?php echo $data_news_1[0]  ?>.jpg" alt="" class="img-responsive">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="post-story">
                                    <div class="post-story-body clearfix"  ">
                                        <p class="txt1" >
                                            <a class="hover_oranye_tipis" style='color:#ffc925; text-decoration:none;' href='news_details.php?details=<?php echo $data_news_1[0] ?>'>
                                                <font  style="font-size: 25px; font-weight: bold; color:#ffc925; line-height: 80%"><?php echo $data_news_1[4] ?></font>
                                            </a>
                                            <br>
                                            <p style="text-align:justify;">
                                                <?php 
                                                    $temp = explode("/>", $data_news_1[3]);

                                                    if($temp[0]==""){
                                                        echo substr(htmlspecialchars_decode($temp[1]),0,180)."&nbsp;<a class='hover_oranye_tipis' style='background:#ffc925; color:black; padding:2px; text-decoration:none;' href='news_details.php?details=$data_news_1[0]'>Read More</a>"; 
                                                    }else{
                                                        echo substr(htmlspecialchars_decode($data_news_1[3]),0,180);
                                                    }
                                                ?>
                                            </p>
                                            <i>By <?php echo $data_news_1[1]; ?> | <?php echo $data_news_1[2] ?></i>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>

                    <div class="pager_wrapper animated" data-animation="fadeInUp" data-animation-delay="500" style="float: left; margin-top: -40px;">
                        <ul class="pager clearfix">
                            <li class="prev"><a href="#">Previous</a></li>
                            <li class="active"><a href="#">1</a></li>
                            <li class="li"><a href="#">2</a></li>
                            <li class="li"><a href="#">3</a></li>
                            <li class="li"><a href="#">4</a></li>
                            <li class="next"><a href="#">Next</a></li>
                        </ul>
                    </div>
                    <div style="clear: both; margin-bottom: 50px;"></div>

                </div> -->
                <div class="col-md-4">
                    
                    
                </div> 
                <div class="col-md-8">
                      
                </div>

                
            </div>
        </div>
</div> <!-- CLOSE DIV BODY -->

    <?php include("../index_parts/page_footer.php"); ?>

</div>

<style type="text/css">
    .backdrop{
        color: white;
    }
    .hover_oranye_tipis:hover{
         opacity: 0.7;
    }
</style>


<script src="../js/jquery.js"></script>
<script src="../js/jquery-ui.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery-migrate-1.2.1.min.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/superfish.js"></script>

<script src="../js/camera.js"></script>

<script src="../js/mediaelement-and-player.js"></script>
<script src="../js/mep-feature-playlist.js"></script>
<script src="../js/slick.min.js"></script>

<script src="../js/jquery.jrumble.1.3.min.js"></script>

<script src="../js/jquery.sticky.js"></script>

<script src="../js/jquery.queryloader2.js"></script>

<script src="../js/jquery.appear.js"></script>

<script src="../js/jquery.ui.totop.js"></script>
<script src="../js/jquery.equalheights.js"></script>

<script src="../js/jquery.caroufredsel.js"></script>
<script src="../js/jquery.touchSwipe.min.js"></script>

<!-- <script src="../js/SmoothScroll.js"></script> -->

<script src="../js/cform.js"></script>

<script src="../js/scripts.js"></script>
</body>

</html>