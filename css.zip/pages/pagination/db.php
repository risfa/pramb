<?php
$dbhost = 'localhost';  
$dbuser = 'dapps';  
$dbpass = "l1m4d1g1t";  
$conn = mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');  
$dbname = 'dapps_joker_masimanetwork_prambors';  
$connection = mysql_select_db($dbname); 
?>  

